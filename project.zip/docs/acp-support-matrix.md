# ACP v1 support matrix

Status reflects the live `ConnectionPool` path, not unused helper modules.

| Method / update / capability | Supported | Capability-gated | Tested | UI | Persistence | Mock scenarios | Notes |
|---|---|---|---|---|---|---|---|
| `initialize` / ACP v1 | Yes | — | Yes | Indirect | Connection snapshot | all | Rejects a non-v1 negotiated protocol. |
| `session/new` | Yes | — | Yes | Yes | `acpSessionId` | all | Creates per turn when no reusable session id. |
| `session/load` | Yes | Agent `load_session` | Unit | Indirect | `acpSessionId` | `load_session` | Load errors surface; no fallback to new session. Replayed updates are suppressed. |
| `session/prompt` text | Yes | — | Yes | Streaming chat | `messages` | `echo`, `slow_stream` | One text content block only. |
| `session/cancel` | Yes | — | Yes | Interrupt button | Final message/error | `cancel_coop` | 15 s grace, then `provider_unresponsive_after_cancel`. |
| `session/set_config_option` (model) | Partial | Agent config options | Unit | Model picker | Thread `model` | `config_model` | The pool path currently does not apply the requested model; older client helper does. |
| `AgentMessageChunk` | Yes | — | Yes | Yes | Legacy assistant message | `echo`, `slow_stream` | Stored/emitted as full text snapshots. |
| `AgentThoughtChunk` | Partial | — | Unit/indirect | Activity only | No | `thought_then_answer` | Becomes `Thinking…`; no thought timeline entry. |
| `ToolCall` / `ToolCallUpdate` | Partial | — | Older client test | Activity only | No | `tool_lifecycle` | Pool notification handler does not currently normalize tool updates. |
| `Plan` | No | — | Mock-only | UI components exist | Field reserved | `plan_update` | Not wired from provider updates. |
| `UsageUpdate` | No | — | Mock-only | UI components exist | Field reserved | `usage_meter` | Not wired from provider updates. |
| `AvailableCommandsUpdate` | No | — | Mock-only | No | No | `slash_commands` | No slash-command integration. |
| `session/request_permission` | Partial | — | Integration | Cards render, resolver contract mismatches host | `timeline`, `pendingPermissions` | `permission_allow`, `permission_tool_race` | Host accepts `{requestId, optionId}`; renderer sends `{permissionId, decision}`. |
| `fs/read_text_file` | Yes | Client advertises FS | Helper/unit coverage | No direct UI | Disk only | `fs_roundtrip` | Workspace-contained disk reads only. |
| `fs/write_text_file` | Yes | Client advertises FS | Helper/unit coverage | No direct UI | Disk only | — | No unsaved-buffer bridge yet. |
| Client terminal methods | No | Not advertised | No | No | No | No | Terminal ACP client is not implemented. |
| Authentication methods | No | Not advertised | No | No | No | No | Profiles may identify auth requirements only. |
| Session resume/close/list/delete | No | Not advertised | No | No | No | No | Only new/load are used. |
| Images/audio/resources in prompt | No | Not advertised | No | No | No | No | Prompt is text-only. |
| Structured sequenced deltas | Partial | — | Module-only | Consumer exists | Fields reserved | — | `EventPipeline` is not wired into live turns. |
| Protocol trace | Partial | — | Unit | Inspector RPC | In memory only | `--trace` peer output | Bounded/redacted `ProtocolTrace` exists but live inspector exposes turn metadata only. |

Provider profiles are launch configuration, not a claim of end-to-end compatibility. See `acp-provider-compatibility.md`.
