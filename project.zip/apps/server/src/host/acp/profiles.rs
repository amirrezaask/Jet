use super::bounds::MAX_RESTARTS;
use super::types::AcpError;
use std::env;
use std::path::PathBuf;
use std::time::Duration;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RestartPolicy {
    Never,
    OnFailure { max_restarts: u32 },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderProfile {
    pub id: &'static str,
    pub executable: &'static str,
    pub spawn_args: Vec<String>,
    pub initialize_timeout: Duration,
    pub turn_timeout: Duration,
    pub stop_timeout: Duration,
    pub restart_policy: RestartPolicy,
    pub quirks: Vec<&'static str>,
    pub is_mock: bool,
}

impl ProviderProfile {
    pub fn resolve_executable(&self) -> Result<PathBuf, AcpError> {
        if !self.is_mock {
            return Ok(PathBuf::from(self.executable));
        }
        if let Some(path) = env::var_os("GHARARGAH_MOCK_ACP_BIN") {
            return Ok(PathBuf::from(path));
        }
        let current = env::current_exe().map_err(|error| AcpError::Profile {
            provider_id: self.id.to_string(),
            message: format!("cannot resolve current executable: {error}"),
        })?;
        Ok(current.with_file_name("gharargah-mock-acp"))
    }
}

fn profile(
    id: &'static str,
    executable: &'static str,
    spawn_args: &[&str],
    quirks: &[&'static str],
    is_mock: bool,
) -> ProviderProfile {
    ProviderProfile {
        id,
        executable,
        spawn_args: spawn_args.iter().map(|arg| (*arg).to_string()).collect(),
        initialize_timeout: Duration::from_secs(120),
        turn_timeout: Duration::from_secs(15 * 60),
        stop_timeout: Duration::from_secs(15),
        restart_policy: RestartPolicy::OnFailure {
            max_restarts: MAX_RESTARTS,
        },
        quirks: quirks.to_vec(),
        is_mock,
    }
}

pub fn cursor_acp() -> ProviderProfile {
    profile(
        "cursor-acp",
        "cursor-agent",
        &["acp"],
        &["permission requests may arrive during a tool update"],
        false,
    )
}

pub fn codex_acp() -> ProviderProfile {
    profile(
        "codex-acp",
        "codex",
        &["acp"],
        &["tool updates can omit a title"],
        false,
    )
}

pub fn claude_acp() -> ProviderProfile {
    profile(
        "claude-acp",
        "claude",
        &["--acp"],
        &["authentication can require interactive completion"],
        false,
    )
}

pub fn opencode_acp() -> ProviderProfile {
    profile(
        "opencode-acp",
        "opencode",
        &["acp"],
        &["session configuration may be unavailable"],
        false,
    )
}

pub fn mock_strict() -> ProviderProfile {
    profile(
        "mock-strict",
        "gharargah-mock-acp",
        &["--scenario", "echo", "--strict"],
        &["rejects malformed protocol messages"],
        true,
    )
}

pub fn mock_compat() -> ProviderProfile {
    profile(
        "mock-compat",
        "gharargah-mock-acp",
        &["--scenario", "echo"],
        &["emits compatibility-shaped updates"],
        true,
    )
}

pub fn mock_chaos() -> ProviderProfile {
    profile(
        "mock-chaos",
        "gharargah-mock-acp",
        &["--scenario", "chaos_malformed", "--strict"],
        &["reorders non-dependent updates and simulates disconnects"],
        true,
    )
}

pub fn all_profiles() -> Vec<ProviderProfile> {
    vec![
        cursor_acp(),
        codex_acp(),
        claude_acp(),
        opencode_acp(),
        mock_strict(),
        mock_compat(),
        mock_chaos(),
    ]
}
