use super::connection_pool::{ConnectionPool, TurnJob};
use super::profiles::ProviderProfile;
use super::types::{ConnectionState, NormalizedEvent, ProviderConnectionSnapshot};
use agent_client_protocol::schema::v1::{RequestPermissionOutcome, RequestPermissionRequest};
use futures_util::future::BoxFuture;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use tokio::sync::{oneshot, watch};
use uuid::Uuid;

pub type SupervisorEventSink = Arc<dyn Fn(u64, NormalizedEvent) + Send + Sync>;

pub struct SupervisorTurnRequest {
    pub provider: ProviderProfile,
    pub workspace_root: PathBuf,
    pub thread_key: String,
    pub prompt: String,
    pub model: Option<String>,
    pub existing_session_id: Option<String>,
    pub on_session: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_text: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_activity: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_event: SupervisorEventSink,
}

pub struct SupervisorTurnResult {
    pub session_id: String,
    pub text: String,
    pub cancelled: bool,
}

struct ActiveTurn {
    cancel: watch::Sender<bool>,
}

struct ConnectionRecord {
    snapshot: ProviderConnectionSnapshot,
    trace: Vec<Value>,
}

#[derive(Clone, Default)]
pub struct AcpSupervisor {
    active: Arc<Mutex<HashMap<String, ActiveTurn>>>,
    permissions: Arc<Mutex<HashMap<String, oneshot::Sender<String>>>>,
    connections: Arc<Mutex<HashMap<String, ConnectionRecord>>>,
    pool: ConnectionPool,
}

impl AcpSupervisor {
    pub fn new() -> Self {
        Self::default()
    }

    pub async fn run_turn(
        &self,
        request: SupervisorTurnRequest,
    ) -> Result<SupervisorTurnResult, String> {
        let connection_key = format!(
            "{}:{}",
            request.provider.id,
            request.workspace_root.display()
        );
        let started_at_ms = now_ms();
        {
            let mut connections = self
                .connections
                .lock()
                .map_err(|_| "ACP connection lock poisoned")?;
            let record = connections
                .entry(connection_key.clone())
                .or_insert_with(|| ConnectionRecord {
                    snapshot: ProviderConnectionSnapshot {
                        provider_id: request.provider.id.to_string(),
                        state: ConnectionState::NotStarted,
                        detail: None,
                        process_id: None,
                        restart_count: 0,
                        started_at_ms: Some(started_at_ms),
                        last_transition_at_ms: started_at_ms,
                        last_error: None,
                    },
                    trace: Vec::new(),
                });
            record.snapshot.state = ConnectionState::Starting;
            record.snapshot.last_transition_at_ms = now_ms();
            record
                .trace
                .push(json!({"event":"turn_start","threadKey":request.thread_key}));
        }
        let (cancel_tx, cancel_rx) = watch::channel(false);
        {
            let mut active = self.active.lock().map_err(|_| "ACP turn lock poisoned")?;
            if active.contains_key(&request.thread_key) {
                return Err("turn_already_running".to_string());
            }
            active.insert(request.thread_key.clone(), ActiveTurn { cancel: cancel_tx });
        }

        let executable = request
            .provider
            .resolve_executable()
            .map_err(|error| error.to_string())?;
        if !executable.exists() {
            let _ = self.active.lock().ok().and_then(|mut active| {
                active.remove(&request.thread_key);
                Some(())
            });
            return Err(format!(
                "ACP provider binary missing: {} (set GHARARGAH_MOCK_ACP_BIN for mock)",
                executable.display()
            ));
        }

        let pending = self.permissions.clone();
        let thread_key = request.thread_key.clone();
        let event = request.on_event.clone();
        let on_permission: Arc<
            dyn Fn(RequestPermissionRequest) -> BoxFuture<'static, RequestPermissionOutcome>
                + Send
                + Sync,
        > = Arc::new(move |permission| {
            let request_id = Uuid::new_v4().to_string();
            let (tx, rx) = oneshot::channel();
            pending
                .lock()
                .expect("ACP permission lock poisoned")
                .insert(request_id.clone(), tx);
            let ui_options: Vec<String> = permission
                .options
                .iter()
                .map(|option| match option.kind {
                    agent_client_protocol::schema::v1::PermissionOptionKind::AllowOnce => {
                        "allow_once".to_string()
                    }
                    agent_client_protocol::schema::v1::PermissionOptionKind::AllowAlways => {
                        "allow_always".to_string()
                    }
                    agent_client_protocol::schema::v1::PermissionOptionKind::RejectOnce
                    | agent_client_protocol::schema::v1::PermissionOptionKind::RejectAlways => {
                        "reject".to_string()
                    }
                    _ => option.option_id.0.to_string(),
                })
                .collect();
            let title = permission
                .tool_call
                .fields
                .title
                .clone()
                .unwrap_or_else(|| "Permission required".to_string());
            let option_ids: Vec<Value> = permission
                .options
                .iter()
                .map(|option| {
                    json!({
                        "id": option.option_id.0.as_ref(),
                        "kind": format!("{:?}", option.kind),
                        "name": option.name,
                    })
                })
                .collect();
            event(
                0,
                NormalizedEvent::Timeline(super::types::TimelineItem {
                    kind: super::types::TimelineItemKind::Permission,
                    id: request_id.clone(),
                    session_id: permission.session_id.0.to_string(),
                    turn_id: Some(thread_key.clone()),
                    payload: json!({
                        "id": request_id,
                        "requestId": request_id,
                        "title": title,
                        "description": null,
                        "scope": null,
                        "options": ui_options,
                        "optionIds": option_ids,
                        "createdAt": chrono::Utc::now().to_rfc3339(),
                        "toolCall": permission.tool_call,
                    }),
                }),
            );
            Box::pin(async move {
                match rx.await {
                    Ok(option_id) => RequestPermissionOutcome::Selected(
                        agent_client_protocol::schema::v1::SelectedPermissionOutcome::new(
                            option_id,
                        ),
                    ),
                    Err(_) => RequestPermissionOutcome::Cancelled,
                }
            })
        });

        let (respond_placeholder, _) = oneshot::channel();
        let result = self
            .pool
            .run_turn(
                connection_key.clone(),
                executable.to_string_lossy().into_owned(),
                request.provider.spawn_args.clone(),
                TurnJob {
                    cwd: request.workspace_root,
                    prompt: request.prompt,
                    model: request.model,
                    existing_session_id: request.existing_session_id,
                    cancel: cancel_rx,
                    on_session: request.on_session,
                    on_text: request.on_text,
                    on_activity: request.on_activity,
                    on_permission,
                    respond: respond_placeholder,
                },
            )
            .await;

        self.active
            .lock()
            .ok()
            .and_then(|mut active| active.remove(&request.thread_key));
        let mut connections = self
            .connections
            .lock()
            .map_err(|_| "ACP connection lock poisoned")?;
        let record = connections
            .get_mut(&connection_key)
            .expect("connection inserted");
        record.snapshot.last_transition_at_ms = now_ms();
        match result {
            Ok(result) => {
                record.snapshot.state = ConnectionState::Ready;
                record
                    .trace
                    .push(json!({"event":"turn_finish","sessionId":result.session_id}));
                Ok(SupervisorTurnResult {
                    session_id: result.session_id,
                    text: result.text,
                    cancelled: matches!(
                        result.stop_reason,
                        agent_client_protocol::schema::v1::StopReason::Cancelled
                    ),
                })
            }
            Err(error) => {
                record.snapshot.state = ConnectionState::Degraded;
                record.snapshot.last_error = Some(error.clone());
                record
                    .trace
                    .push(json!({"event":"turn_error","error":error}));
                Err(error)
            }
        }
    }

    pub fn resolve_permission(&self, request_id: &str, option_id: &str) -> Result<(), String> {
        let sender = self
            .permissions
            .lock()
            .map_err(|_| "ACP permission lock poisoned")?
            .remove(request_id)
            .ok_or("unknown_permission_request")?;
        sender
            .send(option_id.to_string())
            .map_err(|_| "permission_request_closed".to_string())
    }

    pub fn cancel_turn(&self, thread_key: &str) {
        if let Some(turn) = self
            .active
            .lock()
            .ok()
            .and_then(|active| active.get(thread_key).map(|turn| turn.cancel.clone()))
        {
            let _ = turn.send(true);
        }
    }

    pub fn connection_snapshot(&self, provider_id: &str) -> ProviderConnectionSnapshot {
        self.connections
            .lock()
            .ok()
            .and_then(|connections| {
                connections
                    .values()
                    .find(|record| record.snapshot.provider_id == provider_id)
                    .map(|record| record.snapshot.clone())
            })
            .unwrap_or(ProviderConnectionSnapshot {
                provider_id: provider_id.to_string(),
                state: ConnectionState::NotStarted,
                detail: None,
                process_id: None,
                restart_count: 0,
                started_at_ms: None,
                last_transition_at_ms: now_ms(),
                last_error: None,
            })
    }

    pub fn export_trace(&self, provider_id: &str) -> Value {
        self.connections
            .lock()
            .ok()
            .and_then(|connections| {
                connections
                    .values()
                    .find(|record| record.snapshot.provider_id == provider_id)
                    .map(|record| json!({"providerId":provider_id,"entries":record.trace}))
            })
            .unwrap_or_else(|| json!({"providerId":provider_id,"entries":[]}))
    }

    pub fn shutdown(&self) {
        let keys = self
            .active
            .lock()
            .map(|active| active.keys().cloned().collect::<Vec<_>>())
            .unwrap_or_default();
        for key in keys {
            self.cancel_turn(&key);
        }
        self.pool.shutdown();
    }
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}
