//! Long-lived ACP provider connections on the shared Tokio runtime.
//!
//! One OS process + initialized JSON-RPC connection per `(provider, workspace)`.
//! Turns are submitted as jobs; the worker owns initialize once and multiplexes
//! session/new|load + prompt on that connection.

use crate::host::acp::fs_handler::FsHandler;
use agent_client_protocol::schema::v1::{
    CancelNotification, ClientCapabilities, ClientSessionCapabilities, ContentBlock, ContentChunk,
    FileSystemCapabilities, Implementation, InitializeRequest, LoadSessionRequest,
    NewSessionRequest, PromptRequest, ReadTextFileRequest, ReadTextFileResponse,
    RequestPermissionOutcome, RequestPermissionRequest, RequestPermissionResponse, SessionId,
    SessionConfigOptionsCapabilities, SessionNotification, SessionUpdate, StopReason, TextContent,
    WriteTextFileRequest, WriteTextFileResponse,
};
use agent_client_protocol::schema::ProtocolVersion;
use agent_client_protocol::{AcpAgent, Agent, Client, ConnectionTo};
use futures_util::future::BoxFuture;
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::sync::{mpsc, oneshot, watch};

const HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(120);
const CANCELLATION_TIMEOUT: Duration = Duration::from_secs(15);

pub struct AcpTurnResult {
    pub session_id: String,
    pub text: String,
    pub stop_reason: StopReason,
}

pub struct TurnJob {
    pub cwd: PathBuf,
    pub prompt: String,
    pub model: Option<String>,
    pub existing_session_id: Option<String>,
    pub cancel: watch::Receiver<bool>,
    pub on_session: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_text: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_activity: Arc<dyn Fn(&str) + Send + Sync>,
    pub on_permission: Arc<
        dyn Fn(RequestPermissionRequest) -> BoxFuture<'static, RequestPermissionOutcome>
            + Send
            + Sync,
    >,
    pub respond: oneshot::Sender<Result<AcpTurnResult, String>>,
}

struct SharedHandlers {
    cwd: Mutex<PathBuf>,
    capture: AtomicBool,
    output: Mutex<String>,
    on_text: Mutex<Option<Arc<dyn Fn(&str) + Send + Sync>>>,
    on_activity: Mutex<Option<Arc<dyn Fn(&str) + Send + Sync>>>,
    on_permission: Mutex<
        Option<
            Arc<
                dyn Fn(RequestPermissionRequest) -> BoxFuture<'static, RequestPermissionOutcome>
                    + Send
                    + Sync,
            >,
        >,
    >,
}

#[derive(Clone, Default)]
pub struct ConnectionPool {
    inner: Arc<Mutex<HashMap<String, mpsc::Sender<TurnJob>>>>,
}

impl ConnectionPool {
    pub fn new() -> Self {
        Self::default()
    }

    pub async fn run_turn(
        &self,
        connection_key: String,
        command: String,
        args: Vec<String>,
        mut job: TurnJob,
    ) -> Result<AcpTurnResult, String> {
        let tx = {
            let mut guard = self
                .inner
                .lock()
                .map_err(|_| "ACP connection pool lock poisoned")?;
            match guard.get(&connection_key) {
                Some(existing) if !existing.is_closed() => existing.clone(),
                _ => {
                    let tx = spawn_long_lived_worker(connection_key.clone(), command, args);
                    guard.insert(connection_key, tx.clone());
                    tx
                }
            }
        };
        let (respond_tx, respond_rx) = oneshot::channel();
        job.respond = respond_tx;
        tx.send(job)
            .await
            .map_err(|_| "ACP connection worker stopped".to_string())?;
        respond_rx
            .await
            .map_err(|_| "ACP connection worker dropped response".to_string())?
    }

    pub fn shutdown(&self) {
        if let Ok(mut guard) = self.inner.lock() {
            guard.clear();
        }
    }
}

fn spawn_long_lived_worker(
    connection_key: String,
    command: String,
    args: Vec<String>,
) -> mpsc::Sender<TurnJob> {
    let (tx, rx) = mpsc::channel::<TurnJob>(32);
    tokio::spawn(async move {
        if let Err(error) = run_worker(connection_key.clone(), command, args, rx).await {
            tracing::error!(%connection_key, %error, "ACP connection worker failed");
        }
    });
    tx
}

async fn run_worker(
    connection_key: String,
    command: String,
    args: Vec<String>,
    mut rx: mpsc::Receiver<TurnJob>,
) -> Result<(), String> {
    let mut argv = vec![command];
    argv.extend(args);
    let transport = AcpAgent::from_args(argv).map_err(|error| error.to_string())?;
    let first = rx
        .recv()
        .await
        .ok_or_else(|| "ACP connection worker stopped before first turn".to_string())?;
    let shared = Arc::new(SharedHandlers {
        cwd: Mutex::new(first.cwd.clone()),
        capture: AtomicBool::new(false),
        output: Mutex::new(String::new()),
        on_text: Mutex::new(None),
        on_activity: Mutex::new(None),
        on_permission: Mutex::new(None),
    });
    let shared_notify = shared.clone();
    let shared_perm = shared.clone();
    let shared_fs_read = shared.clone();
    let shared_fs_write = shared.clone();

    Client
        .builder()
        .name("gharargah")
        .on_receive_notification(
            {
                async move |notification: SessionNotification, _connection| {
                    if !shared_notify.capture.load(Ordering::Acquire) {
                        return Ok(());
                    }
                    if let SessionUpdate::AgentThoughtChunk(_) = &notification.update {
                        if let Some(on_activity) =
                            shared_notify.on_activity.lock().ok().and_then(|g| g.clone())
                        {
                            on_activity("Thinking…");
                        }
                    }
                    if let SessionUpdate::AgentMessageChunk(ContentChunk {
                        content: ContentBlock::Text(text),
                        ..
                    }) = notification.update
                    {
                        let snapshot = {
                            let mut output = shared_notify.output.lock().map_err(|_| {
                                agent_client_protocol::util::internal_error("output lock poisoned")
                            })?;
                            output.push_str(&text.text);
                            output.clone()
                        };
                        if let Some(on_text) =
                            shared_notify.on_text.lock().ok().and_then(|g| g.clone())
                        {
                            on_text(&snapshot);
                        }
                    }
                    Ok(())
                }
            },
            agent_client_protocol::on_receive_notification!(),
        )
        .on_receive_request(
            {
                async move |request: RequestPermissionRequest, responder, _connection| {
                    let callback = shared_perm
                        .on_permission
                        .lock()
                        .ok()
                        .and_then(|guard| guard.clone());
                    let outcome = match callback {
                        Some(callback) => callback(request).await,
                        None => RequestPermissionOutcome::Cancelled,
                    };
                    responder.respond(RequestPermissionResponse::new(outcome))
                }
            },
            agent_client_protocol::on_receive_request!(),
        )
        .on_receive_request(
            {
                async move |request: ReadTextFileRequest, responder, _connection| {
                    let cwd = shared_fs_read
                        .cwd
                        .lock()
                        .map_err(|_| {
                            agent_client_protocol::util::internal_error("cwd lock poisoned")
                        })?
                        .clone();
                    let handler = FsHandler::new(cwd).map_err(|error| {
                        agent_client_protocol::util::internal_error(error.to_string())
                    })?;
                    let mut content = handler.read_text_file(&request.path).map_err(|error| {
                        agent_client_protocol::util::internal_error(error.to_string())
                    })?;
                    if request.line.is_some() || request.limit.is_some() {
                        let start = request.line.unwrap_or(1).saturating_sub(1) as usize;
                        let limit = request.limit.unwrap_or(u32::MAX) as usize;
                        content = content
                            .lines()
                            .skip(start)
                            .take(limit)
                            .collect::<Vec<_>>()
                            .join("\n");
                    }
                    responder.respond(ReadTextFileResponse::new(content))
                }
            },
            agent_client_protocol::on_receive_request!(),
        )
        .on_receive_request(
            {
                async move |request: WriteTextFileRequest, responder, _connection| {
                    let cwd = shared_fs_write
                        .cwd
                        .lock()
                        .map_err(|_| {
                            agent_client_protocol::util::internal_error("cwd lock poisoned")
                        })?
                        .clone();
                    let handler = FsHandler::new(cwd).map_err(|error| {
                        agent_client_protocol::util::internal_error(error.to_string())
                    })?;
                    handler
                        .write_text_file(&request.path, &request.content)
                        .map_err(|error| {
                            agent_client_protocol::util::internal_error(error.to_string())
                        })?;
                    responder.respond(WriteTextFileResponse::new())
                }
            },
            agent_client_protocol::on_receive_request!(),
        )
        .connect_with(transport, async move |connection| {
            tracing::info!(%connection_key, "ACP provider process connected");
            let initialize = InitializeRequest::new(ProtocolVersion::V1)
                .client_capabilities(
                    ClientCapabilities::new()
                        .session(
                            ClientSessionCapabilities::new()
                                .config_options(SessionConfigOptionsCapabilities::new()),
                        )
                        .fs(
                            FileSystemCapabilities::new()
                                .read_text_file(true)
                                .write_text_file(true),
                        ),
                )
                .client_info(
                    Implementation::new("gharargah", env!("CARGO_PKG_VERSION")).title("Gharargah"),
                );
            let initialized = tokio::time::timeout(
                HANDSHAKE_TIMEOUT,
                connection.send_request(initialize).block_task(),
            )
            .await
            .map_err(|_| agent_client_protocol::util::internal_error("ACP initialize timed out"))??;
            if initialized.protocol_version != ProtocolVersion::V1 {
                return Err(agent_client_protocol::util::internal_error(format!(
                    "unsupported ACP protocol version: {:?}",
                    initialized.protocol_version
                )));
            }

            let load_session = initialized.agent_capabilities.load_session;
            let mut next = Some(first);
            while let Some(job) = next {
                execute_turn_on_connection(&connection, &shared, job, load_session).await;
                next = rx.recv().await;
            }
            Ok(())
        })
        .await
        .map_err(|error| error.to_string())?;
    Ok(())
}

async fn execute_turn_on_connection(
    connection: &ConnectionTo<Agent>,
    shared: &Arc<SharedHandlers>,
    job: TurnJob,
    load_session: bool,
) {
    if let Ok(mut cwd) = shared.cwd.lock() {
        *cwd = job.cwd.clone();
    }
    if let Ok(mut output) = shared.output.lock() {
        output.clear();
    }
    if let Ok(mut on_text) = shared.on_text.lock() {
        *on_text = Some(job.on_text.clone());
    }
    if let Ok(mut on_activity) = shared.on_activity.lock() {
        *on_activity = Some(job.on_activity.clone());
    }
    if let Ok(mut on_permission) = shared.on_permission.lock() {
        *on_permission = Some(job.on_permission.clone());
    }
    shared.capture.store(false, Ordering::Release);

    let TurnJob {
        cwd,
        prompt,
        existing_session_id,
        mut cancel,
        on_session,
        respond,
        ..
    } = job;
    let result = run_prompt(
        connection,
        shared,
        cwd,
        prompt,
        existing_session_id,
        &mut cancel,
        on_session,
        load_session,
    )
    .await;
    let _ = respond.send(result);
}

async fn run_prompt(
    connection: &ConnectionTo<Agent>,
    shared: &Arc<SharedHandlers>,
    cwd: PathBuf,
    prompt: String,
    existing_session_id: Option<String>,
    cancel: &mut watch::Receiver<bool>,
    on_session: Arc<dyn Fn(&str) + Send + Sync>,
    load_session: bool,
) -> Result<AcpTurnResult, String> {
    let (session_id, _config) = if let Some(existing) =
        existing_session_id.clone().filter(|_| load_session)
    {
        let request = LoadSessionRequest::new(existing.clone(), cwd.clone());
        match tokio::time::timeout(HANDSHAKE_TIMEOUT, connection.send_request(request).block_task())
            .await
        {
            Ok(Ok(response)) => (SessionId::new(existing), response.config_options),
            Ok(Err(error)) => return Err(format!("ACP session/load failed: {error}")),
            Err(_) => return Err("ACP session/load timed out".to_string()),
        }
    } else {
        let response = tokio::time::timeout(
            HANDSHAKE_TIMEOUT,
            connection
                .send_request(NewSessionRequest::new(cwd))
                .block_task(),
        )
        .await
        .map_err(|_| "ACP session creation timed out".to_string())?
        .map_err(|error| error.to_string())?;
        (response.session_id, response.config_options)
    };
    on_session(session_id.0.as_ref());
    shared.capture.store(true, Ordering::Release);

    if *cancel.borrow() {
        shared.capture.store(false, Ordering::Release);
        return Ok(AcpTurnResult {
            session_id: session_id.0.to_string(),
            text: shared.output.lock().map(|g| g.clone()).unwrap_or_default(),
            stop_reason: StopReason::Cancelled,
        });
    }

    let prompt = PromptRequest::new(
        session_id.clone(),
        vec![ContentBlock::Text(TextContent::new(prompt))],
    );
    let prompt_request = connection.send_request(prompt).block_task();
    tokio::pin!(prompt_request);
    let mut cancellation_sent = false;
    let cancellation_deadline = tokio::time::sleep(CANCELLATION_TIMEOUT);
    tokio::pin!(cancellation_deadline);
    let response = loop {
        tokio::select! {
            response = &mut prompt_request => break response.map_err(|error| format!("ACP prompt failed: {error}"))?,
            changed = cancel.changed(), if !cancellation_sent => {
                if changed.is_err() || *cancel.borrow() {
                    let _ = connection.send_notification(CancelNotification::new(session_id.clone()));
                    cancellation_sent = true;
                    cancellation_deadline.as_mut().reset(
                        tokio::time::Instant::now() + CANCELLATION_TIMEOUT,
                    );
                }
            }
            _ = &mut cancellation_deadline, if cancellation_sent => {
                return Err("provider_unresponsive_after_cancel".to_string());
            }
        }
    };
    shared.capture.store(false, Ordering::Release);
    Ok(AcpTurnResult {
        session_id: session_id.0.to_string(),
        text: shared.output.lock().map(|g| g.clone()).unwrap_or_default(),
        stop_reason: response.stop_reason,
    })
}
