use jet_server::host::acp::{mock_strict, AcpSupervisor, SupervisorTurnRequest};
use std::sync::{Arc, Mutex};
use std::time::Duration;

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn supervisor_runs_echo_scenario_through_shared_pool() {
    let binary = std::env::var("CARGO_BIN_EXE_gharargah-mock-acp")
        .expect("Cargo must provide the mock ACP binary path");
    std::env::set_var("GHARARGAH_MOCK_ACP_BIN", &binary);

    let supervisor = AcpSupervisor::new();
    let mut profile = mock_strict();
    profile.spawn_args = vec![
        "--scenario".to_string(),
        "echo".to_string(),
        "--strict".to_string(),
    ];
    let texts = Arc::new(Mutex::new(Vec::<String>::new()));
    let texts_cb = texts.clone();
    let result = tokio::time::timeout(
        Duration::from_secs(20),
        supervisor.run_turn(SupervisorTurnRequest {
            provider: profile,
            workspace_root: std::env::current_dir().expect("cwd"),
            thread_key: "test-thread".to_string(),
            prompt: "supervisor smoke".to_string(),
            model: None,
            existing_session_id: None,
            on_session: Arc::new(|_| {}),
            on_text: Arc::new(move |text| {
                texts_cb.lock().unwrap().push(text.to_string());
            }),
            on_activity: Arc::new(|_| {}),
            on_event: Arc::new(|_, _| {}),
        }),
    )
    .await
    .expect("supervisor turn timed out")
    .expect("supervisor turn failed");

    assert!(
        result.text.contains("Mock agent reply: supervisor smoke"),
        "unexpected text: {}",
        result.text
    );
    assert!(!result.cancelled);
    assert!(!texts.lock().unwrap().is_empty());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn supervisor_reuses_connection_for_second_turn() {
    let binary = std::env::var("CARGO_BIN_EXE_gharargah-mock-acp")
        .expect("Cargo must provide the mock ACP binary path");
    std::env::set_var("GHARARGAH_MOCK_ACP_BIN", &binary);

    let supervisor = AcpSupervisor::new();
    let mut profile = mock_strict();
    profile.spawn_args = vec![
        "--scenario".to_string(),
        "echo".to_string(),
        "--strict".to_string(),
    ];
    let cwd = std::env::current_dir().expect("cwd");
    for prompt in ["first", "second"] {
        let result = supervisor
            .run_turn(SupervisorTurnRequest {
                provider: profile.clone(),
                workspace_root: cwd.clone(),
                thread_key: format!("thread-{prompt}"),
                prompt: prompt.to_string(),
                model: None,
                existing_session_id: None,
                on_session: Arc::new(|_| {}),
                on_text: Arc::new(|_| {}),
                on_activity: Arc::new(|_| {}),
                on_event: Arc::new(|_, _| {}),
            })
            .await
            .expect("turn");
        assert!(result.text.contains(&format!("Mock agent reply: {prompt}")));
    }
}
