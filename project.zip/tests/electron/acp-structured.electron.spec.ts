import { expect, test } from "@playwright/test"
import { expectLocatorVisible } from "../shell/assert.js"
import { hasPtySpawn, launchJet } from "./_launch.js"

test.describe("ACP structured timeline", () => {
  test.skip(!hasPtySpawn(), "node-pty cannot spawn a shell on this machine")

  test("mock ACP streams a simple reply", async () => {
    const { app, page } = await launchJet({ env: { GHARARGAH_AGENT_MOCK: "1" } })
    try {
      await page.evaluate(() => window.gharargah!.agents!.listAgents())
      await page.getByRole("button", { name: "New session" }).first().click()
      await page.getByRole("menuitem", { name: "Cursor (ACP)" }).click()
      const modal = page.locator("[data-gharargah-terminal-modal]")
      await expectLocatorVisible(modal)
      await expect.poll(() => modal.getAttribute("data-gharargah-session-mode")).toBe("agent")

      const composer = modal.locator('[data-testid="composer-editor"]')
      await expectLocatorVisible(composer, { timeout: 20_000 })
      await composer.click()
      await composer.fill("ACP structured smoke")
      await modal.getByRole("button", { name: "Send message" }).click()

      await expect
        .poll(
          async () => {
            const path = await page.evaluate(
              () => window.__gharargahAgent!.getState().activeWorkspace!,
            )
            const uri = `file://${path}`
            return page.evaluate(
              async ({ uri, path }) => {
                const agents = window.gharargah!.agents!
                const list = await agents.listThreads(uri, path)
                const id = list.threads[0]?.id
                if (!id) return "no-thread"
                const thread = await agents.readThread(uri, path, id)
                const assistant = [...(thread?.messages ?? [])]
                  .reverse()
                  .find(message => message.role === "assistant")
                return `${thread?.status ?? "missing"}::${assistant?.text ?? ""}`
              },
              { uri, path },
            )
          },
          { timeout: 30_000 },
        )
        .toContain("Mock agent reply: ACP structured smoke")

      await expect
        .poll(() => modal.textContent(), { timeout: 10_000 })
        .toContain("Mock agent reply: ACP structured smoke")
    } finally {
      await app.close()
    }
  })

  test.skip("permission_allow resolves through the permission card", async () => {
    // Enable once headed permission-card flows are green in CI.
  })
})
