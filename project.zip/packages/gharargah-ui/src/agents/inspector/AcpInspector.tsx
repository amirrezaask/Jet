import type { AgentConnectionState } from "@gharargah/agents"
import { Bug } from "lucide-react"
import { useState } from "react"
import { Button } from "../../components/ui/button.js"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../../components/ui/dialog.js"

function redact(value: unknown): string {
  return JSON.stringify(value, (key, item) => /token|secret|authorization|password/i.test(key) ? "[redacted]" : item, 2)
}

export function AcpInspector(props: {
  connection: AgentConnectionState | null | undefined
  trace?: unknown
}) {
  const [open, setOpen] = useState(false)
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button type="button" variant="ghost" size="icon-xs" aria-label="Inspect ACP session" onClick={() => setOpen(true)}><Bug /></Button>
      <DialogContent size="wide">
        <DialogHeader>
          <DialogTitle>ACP inspector</DialogTitle>
          <DialogDescription>{props.connection?.status ?? "No connection state"}</DialogDescription>
        </DialogHeader>
        <pre className="max-h-[50vh] overflow-auto rounded-md border bg-muted/30 p-3 font-mono text-xs text-muted-foreground">{redact(props.trace ?? [])}</pre>
      </DialogContent>
    </Dialog>
  )
}
